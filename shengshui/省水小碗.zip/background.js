// 省水小碗 · background service worker
// 负责记录"选择搜索引擎而不是AI"的次数，维护每日/累计计数、更新工具栏徽标

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

async function getState() {
  const data = await chrome.storage.local.get(['totalSaved', 'dailySaved']);
  return {
    totalSaved: data.totalSaved || 0,
    dailySaved: data.dailySaved || {}
  };
}

// 短时间窗口去重：即使 content script 的 sessionStorage 去重失效
// （比如某些搜索引擎是SPA，同一个query触发多次），也不会重复计数
let lastRecordedKey = '';
let lastRecordedAt = 0;
const DEDUPE_WINDOW_MS = 10000;

async function recordSaved(domain, query) {
  const dedupeKey = `${domain}::${query || ''}`;
  const now = Date.now();
  if (dedupeKey === lastRecordedKey && now - lastRecordedAt < DEDUPE_WINDOW_MS) {
    return;
  }
  lastRecordedKey = dedupeKey;
  lastRecordedAt = now;

  const state = await getState();
  const key = todayKey();
  state.totalSaved += 1;
  state.dailySaved[key] = (state.dailySaved[key] || 0) + 1;

  // 只保留最近14天，避免storage无限增长
  const keys = Object.keys(state.dailySaved).sort();
  if (keys.length > 14) {
    for (const k of keys.slice(0, keys.length - 14)) {
      delete state.dailySaved[k];
    }
  }

  await chrome.storage.local.set({
    totalSaved: state.totalSaved,
    dailySaved: state.dailySaved
  });

  updateBadge(state.dailySaved[key]);
}

async function updateBadge(todayCount) {
  let count = todayCount;
  if (count === undefined || count === null) {
    const state = await getState();
    count = state.dailySaved[todayKey()] || 0;
  }
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#3490DC' });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'SEARCH_INSTEAD_OF_AI') {
    recordSaved(message.domain || 'unknown', message.query).then(() => sendResponse({ ok: true }));
    return true; // keep the message channel open for the async response
  }
  if (message?.type === 'MANUAL_INCREMENT') {
    // 手动测试按钮：模拟"记一次省水搜索"，方便在开发者模式下不打开真实搜索引擎也能预览效果
    recordSaved('manual-test', `manual-${Date.now()}`).then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === 'RESET_TODAY') {
    (async () => {
      const state = await getState();
      delete state.dailySaved[todayKey()];
      await chrome.storage.local.set({ dailySaved: state.dailySaved });
      updateBadge(0);
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === 'RESET_ALL') {
    (async () => {
      await chrome.storage.local.set({ totalSaved: 0, dailySaved: {} });
      updateBadge(0);
      sendResponse({ ok: true });
    })();
    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => updateBadge());
chrome.runtime.onStartup.addListener(() => updateBadge());
