// 省水小碗 · background service worker
// 负责记录对话次数、维护每日/累计计数、更新工具栏徽标

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

async function getState() {
  const data = await chrome.storage.local.get(['totalCount', 'dailyCounts']);
  return {
    totalCount: data.totalCount || 0,
    dailyCounts: data.dailyCounts || {}
  };
}

async function recordQuery(domain) {
  const state = await getState();
  const key = todayKey();
  state.totalCount += 1;
  state.dailyCounts[key] = (state.dailyCounts[key] || 0) + 1;

  // 只保留最近14天，避免storage无限增长
  const keys = Object.keys(state.dailyCounts).sort();
  if (keys.length > 14) {
    for (const k of keys.slice(0, keys.length - 14)) {
      delete state.dailyCounts[k];
    }
  }

  await chrome.storage.local.set({
    totalCount: state.totalCount,
    dailyCounts: state.dailyCounts
  });

  updateBadge(state.dailyCounts[key]);
}

async function updateBadge(todayCount) {
  let count = todayCount;
  if (count === undefined || count === null) {
    const state = await getState();
    count = state.dailyCounts[todayKey()] || 0;
  }
  chrome.action.setBadgeText({ text: count > 0 ? String(count) : '' });
  chrome.action.setBadgeBackgroundColor({ color: '#3490DC' });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message?.type === 'AI_QUERY_SENT') {
    recordQuery(message.domain || 'unknown').then(() => sendResponse({ ok: true }));
    return true; // keep the message channel open for the async response
  }
  if (message?.type === 'MANUAL_INCREMENT') {
    recordQuery('manual').then(() => sendResponse({ ok: true }));
    return true;
  }
  if (message?.type === 'RESET_TODAY') {
    (async () => {
      const state = await getState();
      delete state.dailyCounts[todayKey()];
      await chrome.storage.local.set({ dailyCounts: state.dailyCounts });
      updateBadge(0);
      sendResponse({ ok: true });
    })();
    return true;
  }
  if (message?.type === 'RESET_ALL') {
    (async () => {
      await chrome.storage.local.set({ totalCount: 0, dailyCounts: {} });
      updateBadge(0);
      sendResponse({ ok: true });
    })();
    return true;
  }
});

chrome.runtime.onInstalled.addListener(() => updateBadge());
chrome.runtime.onStartup.addListener(() => updateBadge());
