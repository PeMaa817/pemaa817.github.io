// 省水小碗 · content script
// 启发式检测“用户发送了一条对话消息”：
// 在输入框（textarea 或 contenteditable）里按下不带 Shift 的 Enter，
// 或点击看起来像“发送”按钮的元素时，记一次对话。
// 这是demo级别的启发式方法，不追求100%精确，重点是让用户对“每次对话都有环境成本”建立直觉。

(function () {
  const DEBOUNCE_MS = 800;
  let lastSentAt = 0;

  function isComposerElement(el) {
    if (!el) return false;
    const tag = el.tagName?.toLowerCase();
    if (tag === 'textarea') return true;
    if (el.isContentEditable) return true;
    return false;
  }

  function notifySent() {
    const now = Date.now();
    if (now - lastSentAt < DEBOUNCE_MS) return; // 防止重复计数
    lastSentAt = now;
    chrome.runtime.sendMessage({
      type: 'AI_QUERY_SENT',
      domain: location.hostname
    });
  }

  document.addEventListener(
    'keydown',
    (e) => {
      if (e.key === 'Enter' && !e.shiftKey && !e.isComposing && isComposerElement(e.target)) {
        notifySent();
      }
    },
    true
  );

  // 兜底：点击文本里含“发送/Send”的按钮，或 aria-label 含 send 的按钮
  document.addEventListener(
    'click',
    (e) => {
      const btn = e.target.closest?.('button, [role="button"]');
      if (!btn) return;
      const label = (btn.getAttribute('aria-label') || btn.innerText || '').toLowerCase();
      if (label.includes('send') || label.includes('发送')) {
        notifySent();
      }
    },
    true
  );
})();
