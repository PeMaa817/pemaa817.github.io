// 省水小碗 · content script
// 概念：不是"用了AI就记一次消耗"，而是反过来——
// 每次你打开搜索引擎的结果页（说明这次你选择了搜索引擎而不是去问AI聊天机器人），
// 就把"这次原本可能被一次AI对话消耗掉的能源/水资源"记为一次"省下来了"，
// 交给background记录，最终在popup里体现为animal喝水的奖励动画。
// 这是demo级别的启发式方法：用"打开了搜索结果页"近似"选择了搜索引擎"，
// 不追求100%精确，重点是让"搜索优先"这个选择被看见、被鼓励。

(function () {
  const QUERY_PARAM_CANDIDATES = ['q', 'wd', 'word', 'query', 'p'];

  function extractQuery() {
    const params = new URLSearchParams(location.search);
    for (const key of QUERY_PARAM_CANDIDATES) {
      const val = params.get(key);
      if (val && val.trim()) return val.trim();
    }
    return null;
  }

  function notifySearched(query) {
    const dedupeKey = `shengshui_seen_${location.hostname}_${query}`;
    try {
      if (sessionStorage.getItem(dedupeKey)) return; // 同一标签页内，同一次搜索只记一次
      sessionStorage.setItem(dedupeKey, '1');
    } catch (e) {
      // sessionStorage 不可用时不做去重，background 端仍有短时间窗口去重兜底
    }
    chrome.runtime.sendMessage({
      type: 'SEARCH_INSTEAD_OF_AI',
      domain: location.hostname,
      query
    });
  }

  const query = extractQuery();
  if (query) {
    notifySearched(query);
  }
})();
