// 省水小碗 · popup 逻辑
// 能耗/水耗系数取自 Jegham et al. 2025《How Hungry is AI?》
// 中等规模模型、中等长度对话的粗略中位数：约 0.7 Wh / 3 mL 每次对话
// （轻量模型可低至 <0.1 Wh / <2 mL；重推理模型可高至 30+ Wh / 150+ mL —— 差异巨大，
//  这正是本插件想让用户直观感受到的部分，而不是给出一个虚假精确的单一数字）
const ENERGY_PER_QUERY_WH = 0.7;
const WATER_PER_QUERY_ML = 3;
const MAX_QUEUE_PER_OPEN = 6; // 一次打开弹窗最多补播几只动物，避免长时间没开导致排队过长

function todayKey() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

function fmt(n, digits = 1) {
  return Number(n).toFixed(digits).replace(/\.0$/, '');
}

// ---- 动物排队动画 ----
let animalQueue = [];
let animating = false;

function enqueueVisits(n) {
  const count = Math.min(n, MAX_QUEUE_PER_OPEN);
  for (let i = 0; i < count; i++) {
    animalQueue.push(ANIMALS[Math.floor(Math.random() * ANIMALS.length)]);
  }
  processQueue();
}

function processQueue() {
  if (animating || animalQueue.length === 0) return;
  animating = true;
  const animal = animalQueue.shift();
  playVisit(animal).then(() => {
    animating = false;
    processQueue();
  });
}

function playVisit(animal) {
  return new Promise((resolve) => {
    const stage = document.getElementById('stage');
    const el = document.createElement('div');
    el.className = 'animal walk-in';
    el.innerHTML = animal.svg;
    el.title = animal.name;
    el.addEventListener('click', () => showFact(animal));
    stage.appendChild(el);

    el.addEventListener('animationend', function handler(e) {
      if (e.animationName === 'walkIn') {
        el.classList.remove('walk-in');
        el.classList.add('drinking');
      } else if (e.animationName === 'drinkBob') {
        el.classList.remove('drinking');
        el.classList.add('walk-out');
      } else if (e.animationName === 'walkOut') {
        el.removeEventListener('animationend', handler);
        el.remove();
        resolve();
      }
    });
  });
}

function showFact(animal) {
  const box = document.getElementById('factBox');
  box.textContent = `${animal.name}：${animal.fact}`;
  box.style.display = 'block';
  clearTimeout(showFact._t);
  showFact._t = setTimeout(() => {
    box.style.display = 'none';
  }, 4000);
}

function setWaterLevel(todayCount) {
  const rect = document.getElementById('waterLevel');
  if (!rect) return;
  const ratio = Math.min(todayCount / 10, 1); // 今日10次对话即视觉上"满碗"
  const maxHeight = 22;
  const height = ratio * maxHeight;
  rect.setAttribute('height', height);
  rect.setAttribute('y', 46 - height);
}

// ---- 主渲染 ----
async function render({ triggerAnimation = false } = {}) {
  const data = await chrome.storage.local.get(['totalCount', 'dailyCounts', 'lastSeenCount']);
  const totalCount = data.totalCount || 0;
  const dailyCounts = data.dailyCounts || {};
  const todayCount = dailyCounts[todayKey()] || 0;
  const lastSeenCount = data.lastSeenCount ?? totalCount;

  document.getElementById('todayCount').textContent = todayCount;
  document.getElementById('totalCount').textContent = totalCount;
  document.getElementById('todayEnergy').textContent = fmt(todayCount * ENERGY_PER_QUERY_WH);
  document.getElementById('totalEnergy').textContent = fmt(totalCount * ENERGY_PER_QUERY_WH);
  document.getElementById('todayWater').textContent = fmt(todayCount * WATER_PER_QUERY_ML);
  document.getElementById('totalWater').textContent = fmt(totalCount * WATER_PER_QUERY_ML);
  setWaterLevel(todayCount);

  if (triggerAnimation && totalCount > lastSeenCount) {
    enqueueVisits(totalCount - lastSeenCount);
  }
  await chrome.storage.local.set({ lastSeenCount: totalCount });
}

document.getElementById('manualBtn').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'MANUAL_INCREMENT' });
  render({ triggerAnimation: true });
});

document.getElementById('resetTodayBtn').addEventListener('click', async () => {
  await chrome.runtime.sendMessage({ type: 'RESET_TODAY' });
  render();
});

render({ triggerAnimation: true });
