// 省水小碗 · 动物来喝水
// 简单的扁平SVG小图标（不是照片，避免版权/授权问题，也是这个环境里能稳定实现的方案），
// 每种动物配一句真实、通用的小知识，点击动物时展示。

const ANIMALS = [
  {
    id: 'cat',
    name: '猫',
    fact: '猫是专性肉食动物，一天中的大部分时间都在睡觉和休息。',
    svg: `<svg viewBox="0 0 100 80" width="56" height="45">
      <ellipse cx="50" cy="52" rx="26" ry="18" fill="#c98b5e"/>
      <circle cx="72" cy="30" r="16" fill="#c98b5e"/>
      <polygon points="60,20 66,4 72,18" fill="#c98b5e"/>
      <polygon points="80,18 86,4 88,20" fill="#c98b5e"/>
      <circle cx="67" cy="30" r="2" fill="#3a2417"/>
      <circle cx="78" cy="30" r="2" fill="#3a2417"/>
      <path d="M50 76 Q30 70 22 54" stroke="#c98b5e" stroke-width="6" fill="none" stroke-linecap="round"/>
    </svg>`
  },
  {
    id: 'dog',
    name: '狗',
    fact: '狗的嗅觉极其灵敏，能分辨的气味种类远远超过人类。',
    svg: `<svg viewBox="0 0 100 80" width="56" height="45">
      <ellipse cx="48" cy="52" rx="27" ry="19" fill="#e0a860"/>
      <circle cx="74" cy="32" r="17" fill="#e0a860"/>
      <ellipse cx="60" cy="24" rx="7" ry="12" fill="#a5713a" transform="rotate(-20 60 24)"/>
      <ellipse cx="90" cy="26" rx="7" ry="12" fill="#a5713a" transform="rotate(20 90 26)"/>
      <ellipse cx="82" cy="40" rx="6" ry="4" fill="#fff"/>
      <circle cx="70" cy="31" r="2" fill="#3a2417"/>
      <circle cx="80" cy="31" r="2" fill="#3a2417"/>
      <path d="M46 76 Q28 68 24 58" stroke="#e0a860" stroke-width="6" fill="none" stroke-linecap="round"/>
    </svg>`
  },
  {
    id: 'bird',
    name: '麻雀',
    fact: '麻雀是城市里最常见的野生鸟类之一，几乎全年都能看到它们。',
    svg: `<svg viewBox="0 0 100 80" width="50" height="42">
      <ellipse cx="50" cy="46" rx="22" ry="16" fill="#8a6a4e"/>
      <circle cx="76" cy="32" r="10" fill="#8a6a4e"/>
      <polygon points="86,32 96,29 87,37" fill="#d99a3e"/>
      <circle cx="79" cy="30" r="1.6" fill="#241a10"/>
      <path d="M40 42 Q20 40 14 48" stroke="#5b4330" stroke-width="5" fill="none" stroke-linecap="round"/>
      <path d="M42 60 L38 70 M52 62 L52 72" stroke="#5b4330" stroke-width="3" stroke-linecap="round"/>
    </svg>`
  },
  {
    id: 'deer',
    name: '鹿',
    fact: '许多种类的鹿，每年都会脱落并重新长出一对新的鹿角。',
    svg: `<svg viewBox="0 0 100 90" width="58" height="52">
      <ellipse cx="46" cy="58" rx="26" ry="16" fill="#b98a5c"/>
      <circle cx="74" cy="34" r="13" fill="#b98a5c"/>
      <path d="M70 22 L64 6 M72 20 L76 4" stroke="#7a5636" stroke-width="3" fill="none" stroke-linecap="round"/>
      <path d="M80 22 L86 6 M82 20 L78 4" stroke="#7a5636" stroke-width="3" fill="none" stroke-linecap="round"/>
      <circle cx="70" cy="33" r="1.8" fill="#241a10"/>
      <circle cx="79" cy="33" r="1.8" fill="#241a10"/>
      <path d="M26 70 L20 84 M36 72 L34 86 M54 72 L56 86 M62 70 L66 84" stroke="#8a6440" stroke-width="4" stroke-linecap="round"/>
    </svg>`
  },
  {
    id: 'rabbit',
    name: '兔子',
    fact: '兔子的长耳朵除了听声音，还能帮助身体散热。',
    svg: `<svg viewBox="0 0 100 90" width="50" height="46">
      <ellipse cx="48" cy="60" rx="24" ry="17" fill="#e8dfd2"/>
      <circle cx="72" cy="38" r="14" fill="#e8dfd2"/>
      <ellipse cx="64" cy="14" rx="5" ry="16" fill="#e8dfd2" transform="rotate(-12 64 14)"/>
      <ellipse cx="80" cy="14" rx="5" ry="16" fill="#e8dfd2" transform="rotate(12 80 14)"/>
      <circle cx="67" cy="37" r="1.8" fill="#3a2417"/>
      <circle cx="77" cy="37" r="1.8" fill="#3a2417"/>
      <circle cx="24" cy="66" r="6" fill="#fff"/>
    </svg>`
  },
  {
    id: 'fox',
    name: '狐狸',
    fact: '狐狸大多在夜间活动，视觉和听觉都非常敏锐。',
    svg: `<svg viewBox="0 0 100 80" width="56" height="45">
      <ellipse cx="46" cy="52" rx="26" ry="17" fill="#d9702e"/>
      <circle cx="74" cy="32" r="15" fill="#d9702e"/>
      <polygon points="82,26 96,32 84,38" fill="#d9702e"/>
      <polygon points="62,18 68,2 74,16" fill="#d9702e"/>
      <polygon points="82,16 88,2 92,18" fill="#d9702e"/>
      <circle cx="70" cy="31" r="1.8" fill="#241a10"/>
      <circle cx="80" cy="31" r="1.8" fill="#241a10"/>
      <path d="M44 76 Q22 70 16 52 Q26 58 34 54" fill="#d9702e"/>
      <path d="M18 55 Q24 58 30 55" stroke="#fff" stroke-width="3" fill="none" stroke-linecap="round"/>
    </svg>`
  }
];
